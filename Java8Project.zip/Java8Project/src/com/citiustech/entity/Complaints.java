package com.citiustech.entity;

import java.time.LocalDate;

public class Complaints {
	private LocalDate dateReceived,Date_closed;
	private String Product,Sub_product,Issue,Sub_issue,Company_Bank,State,ZIP_code,Submitted_via,Company_response_to_consumer,Timely_response,Consumer_disputed;
	private String complaintID;
	public Complaints() {
		super();
	}
	public LocalDate getDateReceived() {
		return dateReceived;
	}
	public void setDateReceived(LocalDate dateReceived) {
		this.dateReceived = dateReceived;
	}
	public LocalDate getDate_closed() {
		return Date_closed;
	}
	public void setDate_closed(LocalDate date_closed) {
		Date_closed = date_closed;
	}
	public String getProduct() {
		return Product;
	}
	public void setProduct(String product) {
		Product = product;
	}
	public String getSub_product() {
		return Sub_product;
	}
	public void setSub_product(String sub_product) {
		Sub_product = sub_product;
	}
	public String getIssue() {
		return Issue;
	}
	public void setIssue(String issue) {
		Issue = issue;
	}
	public String getSub_issue() {
		return Sub_issue;
	}
	public void setSub_issue(String sub_issue) {
		Sub_issue = sub_issue;
	}
	public String getCompany_Bank() {
		return Company_Bank;
	}
	public void setCompany_Bank(String company_Bank) {
		Company_Bank = company_Bank;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getZIP_code() {
		return ZIP_code;
	}
	public void setZIP_code(String zIP_code) {
		ZIP_code = zIP_code;
	}
	public String getSubmitted_via() {
		return Submitted_via;
	}
	public void setSubmitted_via(String submitted_via) {
		Submitted_via = submitted_via;
	}
	public String getCompany_response_to_consumer() {
		return Company_response_to_consumer;
	}
	public void setCompany_response_to_consumer(String company_response_to_consumer) {
		Company_response_to_consumer = company_response_to_consumer;
	}
	public String getTimely_response() {
		return Timely_response;
	}
	public void setTimely_response(String timely_response) {
		Timely_response = timely_response;
	}
	public String getConsumer_disputed() {
		return Consumer_disputed;
	}
	public void setConsumer_disputed(String consumer_disputed) {
		Consumer_disputed = consumer_disputed;
	}
	public String getComplaintID() {
		return complaintID;
	}
	public void setComplaintID(String complaintID) {
		this.complaintID = complaintID;
	}
	public Complaints(LocalDate dateReceived, LocalDate date_closed, String product, String sub_product, String issue,
			String sub_issue, String company_Bank, String state, String zIP_code, String submitted_via,
			String company_response_to_consumer, String timely_response, String consumer_disputed, String complaintID) {
		super();
		this.dateReceived = dateReceived;
		Date_closed = date_closed;
		Product = product;
		Sub_product = sub_product;
		Issue = issue;
		Sub_issue = sub_issue;
		Company_Bank = company_Bank;
		State = state;
		ZIP_code = zIP_code;
		Submitted_via = submitted_via;
		Company_response_to_consumer = company_response_to_consumer;
		Timely_response = timely_response;
		Consumer_disputed = consumer_disputed;
		this.complaintID = complaintID;
	}
	public Complaints(String complaintID) {
		super();
		this.complaintID = complaintID;
	}
	
	
	

	
	
	
}


