package com.citiustech.utils;

import java.util.List;

import com.citiustech.entity.Complaints;

public interface IService {

    public List<Complaints> getComplaintById(int complaintId);
	
	public List<Complaints> getComplaintByYear(int year);
	
	public List<Complaints> getComplaintByBankName(String bankName);
	
	public long getComplaintResolutionPeriod(int complaintId);

}
