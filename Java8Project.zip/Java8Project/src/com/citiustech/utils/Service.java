package com.citiustech.utils;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

import com.citiustech.ComplaintsLoader;
import com.citiustech.entity.Complaints;



public class Service implements IService {
	
	List<Complaints> complaints =  ComplaintsLoader();

	@Override
	public List<Complaints> getComplaintById(int complaintId) {
		return complaints.stream().filter(c -> c.getComplaintID().equals(Integer.toString(complaintId))).collect(Collectors.toList());
	}

	@Override
	public List<Complaints> getComplaintByYear(int year) {
		return complaints.stream().filter(c -> c.getDateReceived().getYear() == year).collect(Collectors.toList());
	}

	@Override
	public List<Complaints> getComplaintByBankName(String bankName) {
		return complaints.stream().filter(c -> c.getCompany_Bank().equals(bankName)).collect(Collectors.toList());
	}

	@Override
	public long getComplaintResolutionPeriod(int complaintId) {
		Complaints complaint = complaints.stream().filter(c -> c.getComplaintID().equals(Integer.toString(complaintId))).findFirst().get();
		long days = ChronoUnit.DAYS.between(complaint.getDateReceived(), complaint.getDate_closed());
		return days;
		
	}
	
	

}
