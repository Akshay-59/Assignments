package com.citiustech;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.citiustech.entity.Complaints;

public class ComplaintsLoader {

	public static void main(String[] args)
		throws IOException
	{

		List<String> listOfStrings
			= new ArrayList<>();

		BufferedReader bf = new BufferedReader(
			new FileReader("complaints.csv"));
	
		
	String line =bf.readLine();
		while (line != null) { 
			listOfStrings.add(line);
			line = bf.readLine();
		}
	
	
		bf.close();

		String [] array
			= listOfStrings.toArray(new String[0]);
	
		
//		for (String str : array) {
//			System.out.println(str);
//		}
		   System.out.println("Enter the Complaint ID::");
		    Complaints s=new Complaints();
		listOfStrings.stream().forEach(p->System.out.println(p));
		
		
		

		
		
		
		System.out.println("Service Will Start Here ::");
	}
}
